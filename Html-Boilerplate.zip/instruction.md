# Photoshop basics

- Phím alt + con mắt và click chuột trái vào
- Image -> trim
- File -> Export -> Save for web (ctrl + shift + alt + s)
- Hoặc chuột phải vào layer chọn "Export to PNG"
